


<p align="center">
  <h1 align="center" style="font-family: 'Orbitron', sans-serif; text-shadow: 0 0 10px #00ffff, 0 0 20px #0088ff;">𝐁.𝐌.𝐁-𝐗𝐌𝐃</h1>
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=ff0000&center=true&width=1000&height=200&lines=BMB-XMD-V4.0" alt="Typing SVG" /></a>
  </p>
  
---
  </p>

```
Dont forget to fork & star repo
```

---

<div align="center">
  <img src="https://files.catbox.moe/eru8qg.jpg" width="300" style="border-radius: 20px; box-shadow: 0 0 20px #00ffff;"/>
</div>


<div align="center">
  <img src="https://github.com/bmbxmd/B.M.B-XMD/blob/main/assets/divider.gif?raw=true" width="100%"/>
</div>
<div align="center">
  <img src="https://github.com/bmbxmd/B.M.B-XMD/blob/main/assets/deployheader.gif?raw=true" width="80%"/>
</div>

            `DEPLOMENT STEPS`

<div style="background: #000000; border: 1px solid #00ffff; border-radius: 15px; padding: 20px; box-shadow: 0 0 15px #00ffff; margin-bottom: 30px;">
  
<div style="background: #111111; padding: 15px; border-radius: 10px; border-left: 3px solid #ff00ff;">
  <a href='https://github.com/bmbxmd/B.M.B-XMD/fork' target="_blank">
    <img src='https://img.shields.io/badge/FORK_REPO-FF5500?style=for-the-badge&logo=github&logoColor=white&labelColor=000000'/>
  </a>
</div>

</div>

<div style="background: #000000; border: 1px solid #ff00ff; border-radius: 15px; padding: 20px; box-shadow: 0 0 15px #ff00ff; margin-bottom: 30px;">
  
  > **⚠️ OPTION ONE**
  <a href='https://bmb-website-code-generator.onrender.com/pair' target="_blank">
    <img src='https://img.shields.io/badge/PAIR_CODE_1-FF7700?style=for-the-badge&logo=matrix&logoColor=white&labelColor=000000'/>
  </a></br>
  
  <div style="height: 10px;"></div>
  
  > **⚠️ OPTION TWO**
  <a href='https://bmb-website-code-generator.onrender.com' target="_blank">
    <img src='https://img.shields.io/badge/PAIR_CODE_2-FF00AA?style=for-the-badge&logo=matrix&logoColor=white&labelColor=000000'/>
  </a>
  <p style="color: #aaaaaa; font-size: 12px; margin-top: 10px;">
    <img src="https://github.com/bmbxmd/B.M.B-XMD/blob/main/assets/warning.gif?raw=true" width="15"/> 

<div align="center">
  <img src="https://github.com/bmbxmd/B.M.B-XMD/blob/main/assets/techwave.gif?raw=true" width="80%"/>
</div>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=ff0000&center=true&width=1000&height=200&lines=DEPLOYMENT.OPTION" alt="Typing SVG" /></a>
  </p>

---

<h4 align="center">2. heroku</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://dashboard.heroku.com/new?template=https://github.com/bmbxmd/B.M.B-XMD/tree/main'' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-heroku ‎Deploy-6971FF?style=for-the-badge&logo=Github&logoColor=white'/< width=150 height=28/p></a>

----------

<h4 align="center">1. TalkDrove Free</h4>
<p style="text-align: center; font-size: 1.2em;">


<p align="center">
<a href='https://talkdrove.com/share-bot/11' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-TalkDrove ‎ deploy-FF004D?style=for-the-badge&logo=heroku&logoColor=white'/< width=150 height=28/p></a>
  
<details>
  
<b><strong><summary align="center" style="color: Yello;">EASIEST METHOD</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 

<h3 align="center"> HOW TO DEPLOY ON TALKDROVE</h3>
<h6 align-"center">
Create Account Here:

https://host.talkdrove.com/auth/signup?ref=9535F15A

Then Login
Claim 10 coins in wallet section
Locate where to deploy your bot
You will see a dashboard of bots listed 


Click next , next
Until you see SUBZERO MD
Then click on it

You will be asked to fill in some stuffs like your session Id , and other stuffs on how you want your bot to be ( bot settings ) , it's not hard I added examples


Get session I'd here:

https://bmb-website-deploy.onrender.com/pair

After you're done filling it
Click deploy button 

If you can't see any deploy button , switch the website to dark mode 

It will show

That's all bot connected

`MR FRANK OFC`</h6>
</details>

--------------


<h4 align="center">3. Koyeb</h4>
<p style="text-align: center; font-size: 1.2em;">


<p align="center">
<a href='https://app.koyeb.com/services/deploy?type=git&repository=mrfrankofcc/B.M.B-XMD[PREFIX]=.&env[SESSION_ID]=&env[ALWAYS_ONLINE]=false&env[MODE]=public&env[AUTO_STATUS_MSG]=Seen%20status%20by%20SUBZERO-MD&env[AUTO_STATUS_REPLY]=false&env[AUTO_STATUS_SEEN]=true&env[AUTO_TYPING]=false&env[ANTI_LINK]=true&env[AUTO_REACT]=false&env[READ_MESSAGE]=false' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-koyeb ‎ deploy-FF009D?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>

-----
<h4 align="center">4. Railway</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="center">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-FF8700?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>

-----

<h4 align="center">5. Render</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-black?style=for-the-badge&logo=render&logoColot=white'/< width=150 height=28/p></a>
--------

<h4 align="center">6. Hugging Face</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="center">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white'/< width=150 height=28/p></a> </a>

<details>
  
<b><strong><summary align="center" style="color: Yello;">EASIEST METHOD 2</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 

<h3 align="center"> HOW TO DEPLOY ON HUGGING FACE</h3>
<h6 align-"center">
*❄️ Deploy bmb xmd On Hugging Face For Free !*

`Specs :`
- v2 CPU
- 16GB RAM

> `Steps to deploy`

`Step 1`
1. Go to hugginface.co/join and create an account and verify your email too.

`Step 2`
1. Go to https://huggingface.co/spaces/bmbxmd/B.M.B-XMD

2. Tap on *three dots* _(as shown in image)_

3. Tap on *duplicate space* _(as shown in image)_

`Step 3`
1. Fill your details, e.g., Session ID, Bot Name, owner number etc...

2. Tap on *duplicate space shown below*

```After that wait 10 seconds & your have deployed it successfuly  for free 24/7```

> CREDITS BMB-XMD🎐

*by bmb xmd tech*</h6>

</details>

--------------


<h4 align="center">7. Replit</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="center">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-1976D2?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> </a>

 --------
 <h4 align="center">8. Workflow</h4>
<p style="text-align: center; font-size: 1.2em;">


<details>

<b><strong><summary align="center" style="color: Yello;">Deploy On Workflow</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 
<h8>Copy the workflow codes and then frok the repo edit config add session id then save and now click on repo action tag then click on start new workflow then paste workflow codes name them deploy and save the file</h8>
<h3 align-"center"> Important</h3>
<h6 align-"center">Attention! We do not take responsibility if your github account is suspended through this Deploy method, I advise you not to use this workflow deploy method in the latest github accounts, github accounts created a year or more ago have not received the risk of suspension so far, this works It will only be done for 6 hours, you need to update the code to reactivate it.</h6>

```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```
</details> 

***
